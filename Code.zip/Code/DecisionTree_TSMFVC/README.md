# Run
    1.run cmake .
    2.run make
    3.run ./DecisionTree_TSMFVC
