# Run
    1.run make
    3.run ./ZW1
